import React from 'react'

const CryptoDetails = () => {
  return (
    <div>
      CryptoDetails
    </div>
  )
}

export default CryptoDetails
