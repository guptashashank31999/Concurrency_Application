import React from 'react'

const Cryptocurrencies = () => {
  return (
    <div>
      Cryptocurrencies
    </div>
  )
}

export default Cryptocurrencies
